fx_version 'bodacious'
game 'gta5'
this_is_a_map 'yes'



file 'stream/policesign.ydr'


data_file 'DLC_ITYP_REQUEST' 'stream/policesign_ytyp.ytyp'
