Enseigne Police Nationale

FR
Créateur du model : Clown#2067
Interdiction de partager cette version sans autorisation. 
Tout droits réservé @Ultimate-X Development
Discord : https://discord.gg/DUPMcuwB9q

Installation : 

Pour FiveM il vous suffit de glisser le dossier "FiveM Ready" dans votre serveur, puis renommez le dossier comme vous le souhaitez. ( Exemple : EnseignePN )
Ensuite allez dans votre server.cfg, puis entrer cette ligne : ensure EnseignePN 
Puis faites un Ctrl+S pour sauvegarder et redémarrer votre serveur. 

Enjoy !
 




ENG 
Vehicle Creator : Clown#2067
No sharing of this version without permission.
All rights reserved @Ultimate-X Development
Discord : https://discord.gg/DUPMcuwB9q

Installation:

For FiveM you just need to drag the "FiveM Ready" folder into your server, then rename the folder as you wish. (Example: EnseignePN)
Then go to your server.cfg, then enter this line: enssure EnseignePN
Then press Ctrl+S to backup and restore your server.

Enjoy!